var poly;

$(document).ready(function(){
	$('path').attr('fill', 'rgb(165, 165, 165)'); //устанаваливаем цвет для полигонов, через css это сделать нельзя

    $('path').click(function(e) { //при клике на любую страну
		var offset = $(this).offset(); //создаем переменную offset
		poly = $(this).attr('id'); //наполняем глобальную переменную poly
	 	$('#color_poup').css({"display":"block", "top":offset.top + 20, "left":offset.left + 20}); //при клике на область показываем окно смены цвета
	 	$(this).attr('fill', 'rgb(180, 180, 180)'); //при клике на страну подсвечиваем ее
	 	return poly;
	});

	$('.color_spot').click(function(e){ //устанавливаем цвет для выбранной области
	    var color = $(this).attr('id');
	    switch (color) {
	    	case 'color1':
	    	$('#' + poly).attr('fill', 'rgb(214, 182, 141)').addClass('colored');
	    	break;
	    	case 'color2':
	    	$('#' + poly).attr('fill', 'rgb(101, 74, 63)').addClass('colored');
	    	break;
	    	case 'color3':
	    	$('#' + poly).attr('fill', 'rgb(44, 28, 39)').addClass('colored');
	    	break;
	    }
	});
	
	$('.close').click(function(e) { //закрываем окно по крестику
		$(this).parent().css('display', 'none');
		if($('#' + poly).hasClass('colored')){

		} else {
			$('#' + poly).attr('fill', 'rgb(165, 165, 165)');	
		}
	});

	$('.send_button').click(function(e){ //при нажатии на кнопку "отправить" создаем объект с ID каждой страны и присвоенным ей цветом
		var result = $('path').map(function(idx,v){ 
            return { 
                [$(v).attr('id')]: $(v).attr('fill') 
            } ;
        }).get();
                  
		console.log(result);
	});
});